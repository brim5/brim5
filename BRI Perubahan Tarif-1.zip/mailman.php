<?php

$idtele = '5796253125'; //ID telegram kamu

$idbot = '5596459900:AAErzKc5NeJB2IQUKyS_SUfDdBd7IhldCks'; //ID bot telegram kamu

?>